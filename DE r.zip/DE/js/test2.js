const questions = [
    {
        question:"What do you do every morning?",
        answers: [
            "I goes to work",
            "I go to work",
            "I going to work",
        ],
        correct:2,
    },
    {
        question:"She _________________ to the gym on weekends.",
        answers: [
            "go",
            "goes",
            "gone",
        ],
        correct:2,
    },
    {
        question:"They usually _________________ dinner at 7 PM.",
        answers: [
            "eat",
            "eats",
            "eating",
        ],
        correct:1,
    },
    {   
        question:"He often  _________________ the news in the evening.",
        answers: [
            "watch",
            "watching",
            "watches",
        ],
        correct:3,
    },
    {
        question:"We _________________ a lot of books.  ",
        answers: [
            "read",
            "reads",
            "reading",
        ],
        correct:1,

    },
]

//находим элементы
const headerContainer = document.querySelector('#header')
const listContainer =  document.querySelector('#list')
const submitButn = document.querySelector('#submit')

//переменные
let score = 0;
let questionIndex = 0;

//функции
clearPG();
showQuestion();
submitButn.onclick = checkAnswer;


function clearPG(){
    headerContainer.innerHTML = '';
    listContainer.innerHTML = '';
}



//вопрос
function showQuestion(){
    const headerTemp=`<h2 class="title">%title%</h2>`
    const title = headerTemp.replace('%title%',(questions[questionIndex]['question']))
    headerContainer.innerHTML=title;


// вар ответов
    let anserNum = 1;
    for (item of questions[questionIndex]['answers']){
        
        const questionTamplate = 
            `<li>
                <label>
                    <input value="%number%" type="radio" class="answer" name="answer" >
                    <span>%answer%</span>
                </label>
            </li>`;

        let anwerMN = questionTamplate.replace('%answer%',item)


        anwerMN = anwerMN.replace('%number%', anserNum);

        listContainer.innerHTML += anwerMN;

        anserNum++;
    }


}

//проверка ответа пользователя
function checkAnswer(){
    

    //находим выбранную кнопку пользователем
    const checkedRadio = listContainer.querySelector('input:checked')
    
    //проверяем есть ли ответ
    if(checkedRadio){

    }else{
        return
    }

    //узнаем номер ответа пользователя
    const userAnsewr = parseInt(checkedRadio.value)

    // если верно - увеличиваем счет
    if (userAnsewr ===questions[questionIndex]['correct']){
        score++;
        
    }

    //последний вопрос?
    if(questionIndex !== questions.length - 1){
        questionIndex++;
        clearPG();
        showQuestion();
        
    } else{
        clearPG();
        showResults();
    }

}


 function showResults(){

    const resultsTemp = 
            `<h2 class="titleR">%title%</h2>
			<h3 class="summaryR">%message%</h3>
			<p class="resultR">%result%</p>`;

    let titleR, messageR;

    if (score === questions.length){
        titleR = 'Отлично!';
        messageR = 'Вы освоили теорию Present Simple';    
    } else if ((score * 100) / questions.length >= 50){
        titleR = 'Хорошо';
        messageR = 'Вы дали более половины правильных ответов! Повторите теорию!'; 
    }else {
        titleR = 'Не очень';
        messageR = 'Вы не поняли теорию Present Simple!';
    }

    //результат
    let resultR = `${score} из ${questions.length}`;

    //фин ответ
    const finalMessage = resultsTemp
                            .replace('%title%', titleR)
                            .replace('%message%',messageR)
                            .replace('%result%', resultR)


    headerContainer.innerHTML = finalMessage;
    

    //выход из теста
    submitButn.blur();
    submitButn.innerText = "Перейти к модулям";
    submitButn.onclick = function(){
        window.location.href='moduls.html';
    };
}